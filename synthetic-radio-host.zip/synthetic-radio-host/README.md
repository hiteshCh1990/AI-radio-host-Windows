# 🎙️ Radio AI – Smart RJ Generator

A Python application that generates synthetic radio shows from Wikipedia topics. It creates natural Hinglish conversations between two AI hosts and converts them into audio using text-to-speech technology.

## Features

- 📚 **Wikipedia Integration**: Fetches content from Wikipedia for any topic
- 🤖 **AI Script Generation**: Uses OpenAI GPT-4o-mini to create natural radio conversations
- 🎤 **Dual Voice Hosts**: Two distinct AI voices (Anjli & Hitesh) for realistic radio shows
- 🎵 **Background Music**: Automatically mixes background music with dialogue
- ⚙️ **Audio Settings**: Customize pause duration and background music volume
- 🎶 **Custom Music**: Upload your own background music files
- 📚 **Show History**: Save and manage your generated radio shows
- ✏️ **Script Review**: Edit and approve scripts before audio generation
- 🌐 **Web Interface**: Modern Streamlit-based GUI

## Prerequisites

- Python 3.8 or higher
- OpenAI API key
- ElevenLabs API key
- Internet connection

## Installation

1. **Clone or navigate to the project directory:**
   ```bash
   cd synthetic-radio-host
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Install FFmpeg** (required for audio processing):
   - **Windows**: Download from [FFmpeg website](https://ffmpeg.org/download.html) and add to PATH
   - **macOS**: `brew install ffmpeg`
   - **Linux**: `sudo apt-get install ffmpeg` or `sudo yum install ffmpeg`

4. **Configure API Keys:**
   
   Option 1: Create a `.env` file (recommended):
   ```bash
   cp .env.example .env
   # Edit .env and add your API keys
   ```
   
   Option 2: Set environment variables:
   ```bash
   # Windows PowerShell
   $env:OPENAI_API_KEY="your_key_here"
   $env:ELEVENLABS_API_KEY="your_key_here"
   
   # Windows CMD
   set OPENAI_API_KEY=your_key_here
   set ELEVENLABS_API_KEY=your_key_here
   
   # macOS/Linux
   export OPENAI_API_KEY="your_key_here"
   export ELEVENLABS_API_KEY="your_key_here"
   ```
   
   Option 3: Edit the API keys directly in `app.py` and `engine.py` (not recommended for production)

5. **Add Background Music (Optional):**
   - Place a `bg_music.mp3` file in the `synthetic-radio-host` directory
   - If not provided, the audio will be generated without background music

## Running the Application

### In Cursor (or any IDE):

1. **Open terminal in Cursor** (Terminal → New Terminal)

2. **Navigate to the project directory:**
   ```bash
   cd synthetic-radio-host
   ```

3. **Run the Streamlit app:**
   ```bash
   streamlit run app.py
   ```

4. **The app will open in your browser** automatically at `http://localhost:8501`

### Command Line:

```bash
cd synthetic-radio-host
streamlit run app.py
```

## Usage

1. **Enter a Wikipedia Topic**: Type any topic that exists on Wikipedia (e.g., "National Stock Exchange", "Mumbai", "Python Programming")

2. **Generate Script**: Click "🎧 Generate Script" to create a radio conversation

3. **Review & Edit**: Review the generated script and edit if needed

4. **Configure Audio Settings** (Optional):
   - Adjust pause duration between dialogues (0-2000ms)
   - Set background music volume (-30dB to 0dB)
   - Upload custom background music in the sidebar

5. **Approve & Generate**: Click "✅ Approve & Generate Audio" to create the audio file

6. **Save & Download**: 
   - Listen to the generated audio
   - Click "💾 Save to History" to save the show
   - Download the MP3 file

7. **View History**: Click "📚 Show History & Library" in the sidebar to view all saved shows

## Project Structure

```
synthetic-radio-host/
├── app.py                 # Streamlit GUI application
├── engine.py              # Audio generation engine
├── show_history.py        # Show history management module
├── radio_ai_gui.py        # Original Jupyter notebook GUI (for reference)
├── requirements.txt       # Python dependencies
├── run.bat / run.sh       # Launch scripts
├── .env.example          # API keys template (if exists)
├── bg_music.mp3          # Default background music (optional)
├── custom_bg_music.mp3   # Custom uploaded music (generated)
├── show_history.json     # Show history database (generated)
├── final_radio_show.mp3  # Final output (generated)
├── Audios/               # Generated audio segments (auto-created)
├── tests/                # Test files
│   └── test_engine.py    # Unit tests
└── Docs/                 # Documentation
    ├── Technical_Design.md
    └── Hinglish_Prompt_Explanation.md
```

## How It Works

1. **Content Fetching**: Retrieves Wikipedia summary for the given topic
2. **Script Generation**: Uses OpenAI to create a 30-line Hinglish radio conversation
3. **Script Review**: User can review and edit the generated script
4. **Voice Synthesis**: Converts each dialogue line to speech using ElevenLabs TTS
5. **Audio Processing**: 
   - Adds configurable pauses between dialogues
   - Mixes voice segments with background music
   - Applies volume adjustments
6. **Output**: Generates final MP3 file ready for playback
7. **History**: Optionally saves show to history for later access

## Troubleshooting

### "FFmpeg not found" error
- Install FFmpeg and ensure it's in your system PATH
- Restart your terminal/IDE after installation

### "API key not found" error
- Ensure your API keys are set in environment variables or `.env` file
- Check that the keys are valid and have sufficient credits

### "Topic not found" error
- Try a more specific topic name
- Some topics may have multiple matches - try being more specific

### Audio generation fails
- Check your ElevenLabs API key and account credits
- Ensure you have internet connection
- Check that the script format is correct (Anjli: and Hitesh: prefixes)

## Development

### Running Tests
```bash
cd synthetic-radio-host
python -m pytest tests/
```

**Note**: Some tests require API keys to be set. Set `ELEVENLABS_API_KEY` and `OPENAI_API_KEY` environment variables, or tests will be skipped.

### Original Jupyter Version
The original `radio_ai_gui.py` was designed for Jupyter notebooks/Google Colab. The new `app.py` is optimized for local execution with Streamlit.

## License

This project is for educational and demonstration purposes.

## Notes

- The application requires active internet connection for API calls
- API usage may incur costs based on your OpenAI and ElevenLabs plans
- Generated audio files are saved in the project directory

